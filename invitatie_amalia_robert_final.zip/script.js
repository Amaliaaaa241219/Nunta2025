
function showInvite() {
  document.querySelector('.landing').style.display = 'none';
  document.querySelector('.invite').classList.remove('hidden');
  document.getElementById('bg-music').play();
}
function toggleMusic() {
  var music = document.getElementById('bg-music');
  if (music.paused) {
    music.play();
  } else {
    music.pause();
  }
}
